package com.example.eunju.perfectswingmanager;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by Eunju on 2017-04-24.
 */

public class LookPastVideo extends ActionBarActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.look_past_video);

    }
}
