package com.example.eunju.perfectswingmanager;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;

import com.github.mikephil.charting.charts.CombinedChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Eunju on 2017-04-24.
 */

public class PracticeSwing extends ActionBarActivity {

    class ProData {
        int sequence;
        int left;
        int right;

        ProData(int sequence, int left, int right) {
            this.sequence = sequence;
            this.left = left;
            this.right = right;
        }
    }

    HttpURLConnection connection;
    ArrayList<ProData> arrayList;

    class RequestTask extends AsyncTask<String, Void, Boolean> {

        JSONArray responseArray;

        @Override
        protected Boolean doInBackground(String... urls) {
            // TODO: attempt authentication against a network service.

            try {
                Log.d("Hello", "Hello");
                URL url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();

                connection.setDefaultUseCaches(false);
                connection.setDoInput(true);
                connection.setDoOutput(true);
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setRequestProperty("Cache-Control", "no-cache");

                int responseCode = connection.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream is = connection.getInputStream();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();

                    byte[] byteBuffer = new byte[1024];
                    byte[] byteData = null;
                    int nLength = 0;

                    while ((nLength = is.read(byteBuffer, 0, byteBuffer.length)) != -1)
                        baos.write(byteBuffer, 0, nLength);

                    byteData = baos.toByteArray();

                    String response = new String(byteData);
                    responseArray = new JSONArray(response);

                    if (responseArray.length() > 0)
                        return true;
                }
            }

            catch (Exception e)
            {
                e.printStackTrace();
                return false;
            }

            return false;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            if (success) {
                arrayList = new ArrayList<ProData>();
                Log.d("Hellooooooooooooooooooo", "Hellooooooooooooooooooo");
                // ArrayList에 값 넣기
                for (int i = 0; i < responseArray.length(); i++) {
                    try {

                        JSONObject responseJSON = (JSONObject)responseArray.get(i);
                        ProData proData = new ProData((Integer.parseInt(responseJSON.getString("SEQ"))), Integer.parseInt(responseJSON.getString("LEFT")), Integer.parseInt(responseJSON.getString("RIGHT")));

                        arrayList.add(proData);
                    }

                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

//    private Button btnTest;
    private CombinedChart mChart;
    private Handler handler;
    private int index = 0;
    CombinedData data;
    protected String[] leftright = new String[]{
            "Right" ,"Left"
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.practice_swing);  // layout xml 과 자바파일을 연결

        Intent intent = getIntent();
        int club = intent.getExtras().getInt("club");
//        if(club == 1){
//
//        }else{
//
//        }

//        btnTest = (Button)findViewById(R.id.btnTest);
//
//        btnTest.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                index = 0;
//                handler.sendEmptyMessage(0);
//            }
//        });

        // 받아오는 부분 //
        RequestTask requestTask = new RequestTask();
        requestTask.execute("http://52.231.25.26/psm/select_weight.php?proID=p00001");

        mChart = (CombinedChart) findViewById(R.id.chart1);
        mChart.getDescription().setEnabled(false);
        mChart.setBackgroundColor(Color.WHITE);
        mChart.setDrawGridBackground(false);
        mChart.setDrawBarShadow(false);
        mChart.setHighlightFullBarEnabled(false);

        mChart.setDrawOrder(new CombinedChart.DrawOrder[]{
                CombinedChart.DrawOrder.BAR , CombinedChart.DrawOrder.LINE
        });

        Legend l = mChart.getLegend();
        l.setWordWrapEnabled(true);
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);

        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setDrawGridLines(false);
        rightAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)

        YAxis leftAxis = mChart.getAxisLeft();
        leftAxis.setDrawGridLines(false);
        leftAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)

        XAxis xAxis = mChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTH_SIDED);
        xAxis.setAxisMinimum(0f);
        xAxis.setGranularity(1f);

        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return leftright[(int) value % leftright.length];
            }

            @Override
            public int getDecimalDigits() {
                return 0;
            }
        });

        data = new CombinedData();
        data.setData(generateLineData(20, 40));
        data.setData(generateBarData(20, 40));
        //data.setValueTypeface(mTfLight);

        xAxis.setAxisMaximum(data.getXMax() + 0.70f);

        mChart.setData(data);
        mChart.invalidate();

        handler = new Handler() {
            public void handleMessage(Message msg) {
                if (index < 150) {


                    ProData proData = arrayList.get(index);
                    data.setData(generateLineData(proData.left, proData.right));
                    data.setData(generateBarData(proData.left, proData.right));
                    mChart.setData(data);
                    mChart.invalidate();
                    ++index;
                    handler.sendEmptyMessageDelayed(0, 20); // 메세지 값 설정 필요
                }
            }
        };
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        index = 0;
        handler.sendEmptyMessage(0);
    }
    private LineData generateLineData(int first, int second) {

        LineData d = new LineData();

        ArrayList<Entry> entries = new ArrayList<Entry>();

        entries.add(new Entry(1.25f, first));
        entries.add(new Entry(1.75f, second));

        LineDataSet set = new LineDataSet(entries, "Line");
        set.setColor(Color.rgb(255, 94, 0));
        set.setLineWidth(2.5f);
        set.setCircleColor(Color.rgb(255, 94, 0));
        set.setCircleRadius(5f);
        set.setFillColor(Color.rgb(255, 94, 0));
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setDrawValues(true);
        set.setValueTextSize(20f);
        set.setValueTextColor(Color.rgb(255, 94, 0));

        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        d.addDataSet(set);

        return d;
    }

    private BarData generateBarData(int first, int second) {

        ArrayList<BarEntry> entries1 = new ArrayList<BarEntry>();
        ArrayList<BarEntry> entries2 = new ArrayList<BarEntry>();

        entries1.add(new BarEntry(0, first));
        entries1.add(new BarEntry(0, second));
        entries2.add(new BarEntry(0, first));
        entries2.add(new BarEntry(0, second));

        BarDataSet set1 = new BarDataSet(entries1, "Bar 1");
        set1.setColor(Color.rgb(0, 216, 255));
        set1.setValueTextColor(Color.rgb(0, 216, 255));
        set1.setValueTextSize(0);
        set1.setAxisDependency(YAxis.AxisDependency.LEFT);

        BarDataSet set2 = new BarDataSet(entries2, "Bar 2");
        //   set2.setStackLabels(new String[]{"Stack 1", "Stack 2"});
        //   set2.setColors(new int[]{Color.rgb(60, 220, 78), Color.rgb(60, 220, 78)});
        set2.setColors(Color.rgb(0, 216, 255));
        //  set2.setValueTextColor(Color.rgb(61, 165, 255));
        set2.setValueTextSize(0);
        set2.setAxisDependency(YAxis.AxisDependency.LEFT);

        float groupSpace = 0.10f;
        float barSpace = 0.00f; // x2 dataset
        float barWidth = 0.20f; // x2 dataset //막대바 너비
        // (0.45 + 0.02) * 2 + 0.06 = 1.00 -> interval per "group"

        BarData d = new BarData(set1, set2);
        d.setBarWidth(barWidth);

        // make this BarData object grouped
        d.groupBars(1, groupSpace, barSpace); // start at x = 0

        return d;
    }
}
